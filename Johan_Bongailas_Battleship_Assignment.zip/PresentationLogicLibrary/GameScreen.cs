﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLibrary;

namespace PresentationLogicLibrary
{
    public class GameScreen
    {
        private List<Cell> cells;

        public GameScreen(List<Cell> cells)
        {
            this.cells = cells;
        }

        public GameScreen(List<Attack> attack)
        {
                
        }

        public GameScreen(List<GameShipConfiguration> gameShipConfiguration)
        {

        }

        public void PrintGrid()
        {
            foreach (var cell in cells)
            {
                cell.PrintCell();
            }
        }
    }
}
