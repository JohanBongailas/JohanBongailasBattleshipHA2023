﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PresentationLogicLibrary
{
    public class AttackCell : Cell
    {
        public override void PrintCell()
        {
            Console.Write("X");
        }
    }
}
