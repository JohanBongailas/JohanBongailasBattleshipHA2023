CREATE DATABASE db_battleship;
GO

USE db_battleship;
GO

CREATE SCHEMA battleship;
GO

CREATE TABLE battleship.Players
(
	ID	INT
	    CONSTRAINT PK_battleship_Players_player_id
		PRIMARY KEY
	    IDENTITY(1,1),
	Username NVARCHAR(50)
	         CONSTRAINT UN_battleship_Players_player_username
			 NOT NULL,
	[Password] NVARCHAR(50)
	           NOT NULL
);
GO

CREATE TABLE battleship.Games
(
	ID	INT
	    CONSTRAINT PK_battleship_Games_game_id
		PRIMARY KEY
	    IDENTITY(1,1),
	Title NVARCHAR(50),
	CreatorFK INT 
	          CONSTRAINT FK_battleship_Games_game_CreatorFK
			  FOREIGN KEY(CreatorFK)
			  REFERENCES battleship.Players(ID),
   	OpponentFK INT 
			   CONSTRAINT FK_battleship_Games_game_OpponentFK
			   FOREIGN KEY(OpponentFK)
			   REFERENCES battleship.Players(ID),
	Complete BIT
	         NOT NULL
);

CREATE TABLE battleship.Attacks
(
	ID	INT
	    CONSTRAINT PK_battleship_Attacks_attack_id
		PRIMARY KEY
	    IDENTITY(1,1),
	Coordinate NVARCHAR(50)
	           NOT NULL,
	Hit BIT
	    NOT NULL,
	GameFK INT
	       CONSTRAINT FK_battleship_Attacks_attack_GameFK
		   FOREIGN KEY(GameFK)
		   REFERENCES battleship.Games(ID),
    PlayerID INT
	         CONSTRAINT FK_battleship_Attacks_attack_PlayerID
			 FOREIGN KEY(PlayerID)
			 REFERENCES battleship.Players(ID)
);

CREATE TABLE battleship.Ships
(
	ID INT
	   CONSTRAINT PK_battleship_Ships_ship_id
	   PRIMARY KEY
	   IDENTITY(1, 1),
	Title NVARCHAR(50)
	      NOT NULL,
	Size INT 
	     NOT NULL
);

CREATE TABLE battleship.GameShipConfigurations
(
	ID INT
	   CONSTRAINT PK_battleship_GameShipConfigurations_game_ship_configuration_id
	   PRIMARY KEY
	   IDENTITY(1, 1),
    PlayerFK INT 
	         CONSTRAINT FK_battleship_GameShipConfigurations_game_ship_configuration_CreatorFK
			 FOREIGN KEY(PlayerFK)
			 REFERENCES battleship.Players(ID),
   	GameFK INT
	       CONSTRAINT FK_battleship_GameShipConfigurations_game_ship_configuration_GameFK
		   FOREIGN KEY(GameFK)
		   REFERENCES battleship.Games(ID),
	Coordinate NVARCHAR(50)
	           NOT NULL
);


ALTER TABLE battleship.GameShipConfigurations
ADD ShipFK INT
           CONSTRAINT FK_battleship_GameShipConfigurationShipFK
		   FOREIGN KEY(ShipFK)
		   REFERENCES battleship.Ships(ID)

